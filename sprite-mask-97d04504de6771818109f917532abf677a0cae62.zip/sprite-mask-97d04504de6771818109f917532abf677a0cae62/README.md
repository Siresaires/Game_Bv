# Sprite Mask

A godot sprite mask node plugin !